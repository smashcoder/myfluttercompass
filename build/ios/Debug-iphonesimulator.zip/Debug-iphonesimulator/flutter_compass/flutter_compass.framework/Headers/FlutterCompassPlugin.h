#import <Flutter/Flutter.h>

@interface FlutterCompassPlugin : NSObject<FlutterPlugin>
@end
